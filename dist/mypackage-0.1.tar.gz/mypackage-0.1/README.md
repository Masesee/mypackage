# mypackage
This was an example of how to publish my own python package